      <h2>Ajouter un nouveau Etat</h2>
      <form method="post" action="index.php?action=ajouterEtat">
          <div class="form-group">
              <input class="form-control" id="name" name="nom" type="text" placeholder="Le nom de l'etat" required />
          </div>
          <input type="submit" value="Envoyer" name="submit" class="btn btn-primary" />
      </form>
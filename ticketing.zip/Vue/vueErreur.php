<?php $titre = 'Mon Blog - Erreur'; ?>

<p>Une erreur est survenue : <?= $msgErreur ?></p>
<a href="index.php">Retourner sur l'index</a>

